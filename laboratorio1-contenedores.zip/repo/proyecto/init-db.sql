CREATE DATABASE IF NOT EXISTS mi_base_de_datos;

USE mi_base_de_datos;

CREATE TABLE IF NOT EXISTS mensajes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  mensaje VARCHAR(255) NOT NULL
);

INSERT INTO mensajes (mensaje) VALUES ('¡Hola Mundo desde MariaDB!');
