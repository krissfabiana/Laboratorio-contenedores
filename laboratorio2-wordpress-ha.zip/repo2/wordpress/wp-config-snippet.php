<?php
// Agregar en /home/orh/wp-config.php ANTES de:
// /* That's all, stop editing! Happy publishing. */

/*
 * URL pública servida por HAProxy.
 */
define( 'WP_HOME', 'http://localhost:803' );
define( 'WP_SITEURL', 'http://localhost:803' );

/*
 * Redis Object Cache.
 */
define( 'WP_REDIS_CLIENT', 'phpredis' );
define( 'WP_REDIS_HOST', 'redis' );
define( 'WP_REDIS_PORT', 6379 );
define( 'WP_REDIS_DATABASE', 0 );
define( 'WP_REDIS_PREFIX', 'wordpress-ha:' );

define( 'WP_REDIS_TIMEOUT', 1 );
define( 'WP_REDIS_READ_TIMEOUT', 1 );

/*
 * Permite modificaciones directas realizadas por WordPress.
 * Los archivos continuarán perteneciendo al UID 1003.
 */
define( 'FS_METHOD', 'direct' );
